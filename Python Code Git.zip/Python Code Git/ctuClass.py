#COPYRIGHT BY DILLUN HOLMES AKA:LONEWOLF
class ctuStock:
    def __init__(self):
        self.items = []
        self.shopName = ''
        self.shopLocation = ''

    def add_item(self, item):
        self.items.append(item)

    def remove_item(self, item):
        if item in self.items:
            self.items.remove(item)

    def get_items(self):
        return self.items

    def add_shop(self):
        name = input('Enter new shop name: ')
        location = input('Enter new shop location: ')
        self.shopName = name
        self.shopLocation = location
        print(f'Shop {name} added at {location}')
