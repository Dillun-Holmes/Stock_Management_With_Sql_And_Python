#COPYRIGHT BY DILLUN HOLMES AKA:LONEWOLF

#Importing ctuclass from exsternal file
from ctuClass import ctuStock
 
import sys
import pymysql


#verubales pre set by DEVELOPER
# Replace these values with your own database credentials
host = 'localhost'
database = 'ctu_stock'
user = 'root'
password = '1081'

line1 = ("--------------------------------------------------------------------------")
line2 = ("><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><")
line3 = ("----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------")



try:
    # Establish a connection to the database
    conn = pymysql.connect(
        host=host,
        database=database,
        user=user,
        password=password
    )
    print('Successfully connected to the database!')
    cursor = conn.cursor()
except Exception as e:
    print('Error connecting to the database:', e)
    cursor = conn.cursor()
    cursor.execute()

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

#SHOP MANAGEMENT MENU
def shop_management():
    while True:
        print(line1)
        print('Shop Management')
        print(line1)
        print('1. Change shop name')
        print('2. Change shop location')
        print('3. Display current shops')
        print('4. Display all shops information')
        print('5. Add Shop')
        print('6. Back')
        print('99. Exit')
        choice = input('Enter choice: ')
        if choice == '1':
            print(line1)
            print('Current shops:')
            print(line1)
            cursor = conn.cursor()
            cursor.execute("SELECT shopid, shopname, shoplocation FROM shop")
            rows = cursor.fetchall() 
            width = 20
            print("{:<{}} {:<{}} {:<{}}".format("ID", width, "Shop Name", width, "Location", width))
            print(line1)
            for row in rows:
                print("{:<{}} {:<{}} {:<{}}".format(row[0], width, row[1], width, row[2], width))
            print(line1)
            change_name()
        elif choice == '2':
            print(line1)
            print('Current shops:')
            print(line1)
            cursor = conn.cursor()
            cursor.execute("SELECT shopid, shopname, shoplocation FROM shop")
            rows = cursor.fetchall() 
            width = 20
            print("{:<{}} {:<{}} {:<{}}".format("ID", width, "Shop Name", width, "Location", width))
            print(line1)
            for row in rows:
                print("{:<{}} {:<{}} {:<{}}".format(row[0], width, row[1], width, row[2], width))
            print(line1)
            change_shop_location()
        elif choice == '3':
            display_current_shops()
        elif choice == '4':
            display_all_shops()
        elif choice == '5':
            add_shop()    
        elif choice == '6':
            Main_menu() 
        elif choice == '99':
            break
        else:
            print('Invalid input, please try again.')
#Add new shop to MS SQL DATABASE 
shops = []  # Initialize 'shops' as an empty list

def add_shop():
    name = input('Enter new shop name: ')
    location = input('Enter new shop location: ')
    shop = ctuStock()
    shop.shopName = name
    shop.shopLocation = location
    shops.append(shop)
    
    cursor = conn.cursor()
    cursor.execute(f"INSERT INTO shop(shopname, shoplocation) VALUES ('{name}','{location}')")
    conn.commit()
    
    print(f"Shop '{name}' added at '{location}'")


# Change name of Shops in MS SQL DATABASE import pandas as pd

def change_name():
    shop_id = input("Enter Shop Id ")
    new_name = input("Enter New Name: ")
    cursor.execute(f"UPDATE shop SET shopname = '{new_name}' WHERE shopid = '{shop_id}'")
    conn.commit()
    print(line3)
    print(f"Shop name for ID {shop_id} has been changed to {new_name}")
    print(line3)

# Change location of Shops in MS SQL DATABASE 
def change_shop_location():
    shop_id = input("Enter Shop Id ")
    new_location = input("Enter New location: ")
    cursor.execute("UPDATE shop SET shoplocation = %s WHERE shopid = %s", (new_location, shop_id))
    conn.commit()
    print(f"Shop location for ID {shop_id} has been changed to {new_location}")




# Pulls All shops currently in MS SQL DATABSE and displays it.
def display_current_shops():
    print(line1)
    print('Current shops:')
    print(line1)
    cursor = conn.cursor()
    cursor.execute("SELECT shopid, shopname, shoplocation FROM shop")
    rows = cursor.fetchall() 
    width = 20
    print("{:<{}} {:<{}} {:<{}}".format("ID", width, "Shop Name", width, "Location", width))
    print(line1)
    for row in rows:
        print("{:<{}} {:<{}} {:<{}}".format(row[0], width, row[1], width, row[2], width))
    print(line1)
    print(line2)

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<     

#Display all the shops info 
def display_all_shops():

    cursor = conn.cursor()
    cursor.execute(f"SELECT ShopName, ShopLocation, CustCount, SaleCount, ReturnsCount FROM shop LEFT JOIN (SELECT COUNT(DISTINCT CustomerId) AS CustCount, ShopId FROM SalesHeader GROUP BY ShopId) AS CountCustomers ON shop.ShopId=CountCustomers.ShopId LEFT JOIN (SELECT COUNT(SaleId) AS SaleCount, ShopId FROM SalesHeader GROUP BY ShopId) AS SalesCount ON shop.ShopId=SalesCount.ShopId LEFT JOIN (SELECT COUNT(SalesReturn.SaleId) AS ReturnsCount, SalesHeader.ShopId FROM SalesReturn JOIN SalesHeader ON SalesReturn.SaleId=SalesHeader.SaleId GROUP BY SalesHeader.ShopId) AS SaleReturns ON shop.ShopId=SaleReturns.ShopId;")
    rows = cursor.fetchall()
    print(line1)
    print("All Shop Info")
    print(line1)
    for row in rows: 
        print(f"Shop Name: {row[0]}\nShop Location: {row[1]}\nNumber of Customers: {row[2]}\nNumber of Sales: {row[3]}\nNumber of Returns: {row[4]}\n\n")
    print(line1)


#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#to Add sale
def sales():
        
        print(line1)
        print('Current shops:')
        print(line1)
        cursor = conn.cursor()
        cursor.execute("SELECT shopid, shopname, shoplocation FROM shop")
        rows = cursor.fetchall() 
        width = 20
        print("{:<{}} {:<{}} {:<{}}".format("ID", width, "Shop Name", width, "Location", width))
        print(line1)
        for row in rows:
            print("{:<{}} {:<{}} {:<{}}".format(row[0], width, row[1], width, row[2], width))
        print(line1)
        print(line3)
        cursor = conn.cursor()
        cursor.execute("SELECT  CustomerId,CustomerName FROM customer")
        rows = cursor.fetchall() 
        width = 100
        width1 =15
        print("{:<{}} {:<{}} ".format("ID", width1, "Customer", width))
        print(line3)
        for row in rows:
            print("{:<{}} {:<{}} ".format(row[0], width1, row[1], width))
        print(line3) 
        id5 = int(input('Shop Id: '))
        custom_id = int(input('Customer ID: '))
        cursor = conn.cursor()
        cursor.execute(f"INSERT INTO SalesHeader(ShopId,CustomerId,DateAndTime) VALUES ('{id5}','{custom_id}', NOW())")
        conn.commit()
        print(f'Added Sale: Shop ID:{id5} Customer ID:{custom_id}')
        cursor = conn.cursor()
        cursor.execute("SELECT SaleId FROM SalesHeader ORDER BY SaleId DESC LIMIT 1")
        rows = cursor.fetchall()
        for row in rows:
            Sale_id=(row[0])
        add_sale_item(Sale_id) 

def add_sale_item(Sale_id):
    print(line3)
    print('Stock On Hand:')
    print(line3)
    cursor = conn.cursor()
    cursor.execute("SELECT StockId, StockDescription, QOH, Price FROM stock")
    rows = cursor.fetchall() 
    width = 100
    width1 =15
    print("{:<{}} {:<{}} {:<{}} {:<{}}".format("ID", width1, "Item Name", width, "QOH", width1, "Price", width1))
    print(line3)
    for row in rows:
        print("{:<{}} {:<{}} {:<{}} R {:<{}}".format(row[0], width1, row[1], width, row[2], width1, row[3], width1))
    print(line3)
    Stock_code = input(' Stock Id: ')
    Stock_QTY = input(' Stock QTY: ')
    cursor = conn.cursor()
    cursor.execute(f"SELECT Price FROM stock WHERE StockId = '{Stock_code}'")
    row = cursor.fetchone()
    if not row:
        print(f"Invalid stock code '{Stock_code}'. Please try again.")
        add_sale_item(Sale_id)
        return
    selling_price = row[0]
    cursor.execute(f"INSERT INTO SalesItem (SaleId,StockId,QTY,SellingPrice) VALUES ('{Sale_id}','{Stock_code}','{Stock_QTY}','{selling_price}')")
    cursor.execute(f"UPDATE stock SET QOH = QOH-'{Stock_QTY}' WHERE StockId = '{Stock_code}'")

    conn.commit()
    next_1(Sale_id) 

def next_1(Sale_id):
    print('1. Add another item')
    print('99. Exit')
    choice = input('Enter choice: ')
    if choice == '1':
        add_sale_item(Sale_id)
    elif choice == '99':
        sys.exit()

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
# Returns items and adds stock returnd to the Qty 
def sales_return():
    line1 = "-" * 80
    print(line1)
    print('Sales List:')
    print(line1)
    cursor = conn.cursor()
    cursor.execute("SELECT SaleId, shop.ShopName, customer.CustomerName, DateAndTime FROM SalesHeader join customer on SalesHeader.CustomerId=customer.CustomerId join shop on SalesHeader.ShopId=shop.ShopId")
    rows = cursor.fetchall() 
    width = 20
    print("{:<{}} {:<{}} {:<{}} {:<{}}".format("Sale ID", width, "Shop", width, "Customer", width, "Date and Time", width))
    print(line1)
    for row in rows:
        print("{:<{}} {:<{}} {:<{}} {:<{}}".format(row[0], width, row[1], width, row[2], width, str(row[3]), width*2))

    print(line1)
    sale_id = input('Enter Sale ID to return item(s): ')
    cursor = conn.cursor()
    cursor.execute("SELECT SaleId, ShopId, CustomerId, DateAndTime FROM SalesHeader WHERE SaleId = %s", (sale_id,))
    row = cursor.fetchone()
    if not row:
        print(f"Invalid Sale ID '{sale_id}'. Please try again.")
        sales_return()
        return
        
    print(line1)
    print(f"Sale ID: {row[0]}")
    print(f"Shop ID: {row[1]}")
    print(f"Customer ID: {row[2]}")
    print(f"Date and Time: {row[3]}")
    print(line1)
    cursor.execute("SELECT SaleId, StockId, QTY, SellingPrice FROM SalesItem WHERE SaleId = %s", (sale_id,))
    rows = cursor.fetchall() 
    width = 20
    print("{:<{}} {:<{}} {:<{}} {:<{}}".format("Sale ID", width, "Item ID", width, "QTY", width, "Selling Price", width))
    print(line1)
    for row in rows:
        print("{:<{}} {:<{}} {:<{}} {:<{}}".format(row[0], width, row[1], width, row[2], width, row[3], width))
    print(line1)
    
    item_id = input('Enter Item ID to return: ')
    if not item_id:
        print("Item ID is empty. Please try again.")
        sales_return()
        return

    qty = input('Enter QTY to return: ')

    stock_id = item_id
    cursor.execute("UPDATE SalesItem SET QTY = QTY - %s WHERE SaleId = %s and StockId = %s", (qty, sale_id, item_id))
    cursor.execute("UPDATE stock SET QOH = QOH + %s WHERE StockId = %s", (qty, stock_id))
    cursor.execute("INSERT INTO SalesReturn (SaleId, StockId, QTY, DateAndTime) VALUES (%s, %s,%s , NOW())", (sale_id, stock_id, qty))
    conn.commit()

    cursor.execute("SELECT QTY FROM SalesItem WHERE SaleId = %s and StockId = %s", (sale_id, item_id))

    row = cursor.fetchone()
    if not row:
        print(f"Invalid Item ID '{item_id}'. Please try again.")
        sales_return()
        return
   
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<         
#
# To Add sale
def sales():
        
        print(line1)
        print('Current shops:')
        print(line1)
        cursor = conn.cursor()
        cursor.execute("SELECT shopid, shopname, shoplocation FROM shop")
        rows = cursor.fetchall() 
        width = 20
        print("{:<{}} {:<{}} {:<{}}".format("ID", width, "Shop Name", width, "Location", width))
        print(line1)
        for row in rows:
            print("{:<{}} {:<{}} {:<{}}".format(row[0], width, row[1], width, row[2], width))
        print(line1)
        print(line3)
        cursor = conn.cursor()
        cursor.execute("SELECT  CustomerId,CustomerName FROM customer")
        rows = cursor.fetchall() 
        width = 100
        width1 =15
        print("{:<{}} {:<{}} ".format("ID", width1, "Customer", width))
        print(line3)
        for row in rows:
            print("{:<{}} {:<{}} ".format(row[0], width1, row[1], width))
        print(line3) 
        id5 = int(input('Shop Id: '))
        custom_id = int(input('Customer ID: '))
        cursor = conn.cursor()
        cursor.execute(f"INSERT INTO SalesHeader(ShopId,CustomerId,DateAndTime) VALUES ('{id5}','{custom_id}', NOW())")
        conn.commit()
        print(f'Added Sale: Shop ID:{id5} Customer ID:{custom_id}')
        cursor = conn.cursor()
        cursor.execute("SELECT SaleId FROM SalesHeader ORDER BY SaleId DESC LIMIT 1")
        rows = cursor.fetchall()
        for row in rows:
            Sale_id=(row[0])
        add_sale_item(Sale_id) 

def add_sale_item(Sale_id):
    print(line3)
    print('Stock On Hand:')
    print(line3)
    cursor = conn.cursor()
    cursor.execute("SELECT StockId,StockDescription,QOH,Price FROM stock")
    rows = cursor.fetchall() 
    width = 100
    width1 =15
    print("{:<{}} {:<{}} {:<{}} {:<{}}".format("ID", width1, "Item Name", width, "QOH", width1, "Price", width1))
    print(line3)
    for row in rows:
        print("{:<{}} {:<{}} {:<{}} R {:<{}}".format(row[0], width1, row[1], width, row[2], width1, row[3], width1))
    print(line3)
    Stock_code = input(' Stock Id: ')
    Stock_QTY = input(' Stock QTY: ')
    cursor = conn.cursor()
    cursor.execute(f"SELECT Price FROM stock WHERE StockId = '{Stock_code}'")
    row = cursor.fetchone()
    if not row:
        print(f"Invalid stock code '{Stock_code}'. Please try again.")
        add_sale_item(Sale_id)
        return
    selling_price = row[0]
    cursor.execute(f"INSERT INTO SalesItem (SaleId,StockId,QTY,SellingPrice) VALUES ('{Sale_id}','{Stock_code}','{Stock_QTY}','{selling_price}')")
    cursor.execute(f"UPDATE stock SET QOH = QOH-'{Stock_QTY}' WHERE StockId = '{Stock_code}'")
    conn.commit()
    next_1(Sale_id) 

def next_1(Sale_id):
    print('1. Add another item')
    print('2. Back')
    print('99. Exit')
    choice = input('Enter choice: ')
    if choice == '1':
        add_sale_item(Sale_id)
    elif choice == '2':
            Main_menu()    
    elif choice == '99':
        sys.exit()
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< 
#Customer Menu
def customer3():
    while True:
        print('\nStock')
        print('1. Add Customer ')
        print('2. Edit Customer')
        print('3. Back')
        print('99. Exit')
        choice = input('Enter choice: ')
        if choice == '1':
            add_custom()
        elif choice == '2':
            edit_custom()
        elif choice == '3':
            Main_menu()    
        elif choice == '99':
            break  

#ADDS new Customer to MS SQL DATABASE
def add_custom():
    print('Add Customer:')
    custom1_name = input('Enter Customer name: ')
    cursor = conn.cursor()
    cursor.execute(f"INSERT INTO customer(CustomerName) VALUES ('{custom1_name}')")
    conn.commit()
    print(f'Added Customer : {custom1_name} ')
   
#Edit customer name
def edit_custom():
        print('\nEdit Customer')
        print(line3)
        print('Customer:')
        print(line3)
        cursor = conn.cursor()
        cursor.execute("SELECT  CustomerId,CustomerName FROM customer")
        rows = cursor.fetchall() 
        width = 100
        width1 =15
        print("{:<{}} {:<{}} ".format("ID", width1, "Customer", width))
        print(line3)
        for row in rows:
            print("{:<{}} {:<{}} ".format(row[0], width1, row[1], width))
        print(line3) 

        custom_id = input("Enter Customer Id ")
        new_name= input("Enter New Name: ")
        cursor.execute("UPDATE customer SET CustomerName = %s WHERE CustomerId = %s", (new_name, custom_id))
        conn.commit()

#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<     
#STOCK MENU
def stock():
    while True:
        print('\nStock')
        print('1. Display stock')
        print('2. Add stock')
        print('3. Edit stock')
        print('4. Back')
        print('99. Exit')
        choice = input('Enter choice: ')
        if choice == '1':
            display_stock()
        elif choice == '2':
            add_item()
        elif choice == '3':
            edit()   
        elif choice == '4':
            Main_menu()
        elif choice == '4':
            break            
        else:
            print('Invalid input, please try again.')
      
#STOCK MENU FOR EDIT
def edit():
    while True:
        print('\nEdit stock')
        print(line3)
        print('Stock On Hand:')
        print(line3)
        cursor = conn.cursor()
        cursor.execute("SELECT StockId, StockDescription, QOH, Price FROM stock")
        rows = cursor.fetchall() 
        width = 100
        width1 = 15
        print("{:<{}} {:<{}} {:<{}} {:<{}}".format("ID", width1, "Item Name", width, "QOH", width1, "Price", width1))
        print(line3)
        for row in rows:
            print("{:<{}} {:<{}} {:<{}} R {:<{}}".format(row[0], width1, row[1], width, row[2], width1, row[3], width1))
        print(line3)


        print('1. Description')
        print('2. QOH')
        print('3. Price')
        print('4. Back')
        print('99. Exit')
        choice = input('Enter choice: ')
        if choice == '1':
            edit_prod1()
        elif choice == '2':
            edit_prod2()
        elif choice == '3':
            edit_prod3()
        elif choice == '4':
            stock()    
        elif choice == '99':
            break    
        else:
            print('Invalid input, please try again.') 

#Edit product description 
def edit_prod1():
    product_id = input("EnterItem Id ")
    new_description= input("Enter New Description: ")
    cursor.execute("UPDATE stock SET StockDescription = %s WHERE StockId = %s", (new_description, product_id))
    conn.commit()

    print(f"Shop name for ID {product_id} has been changed to {new_description}")

#Edit Product price
def edit_prod2():
    product_id1 = input("Enter Item Id ")
    new_Qty= input("Enter QTY: ")
    cursor.execute("UPDATE stock SET QOH = QOH+%s WHERE StockId = %s", (new_Qty, product_id1))
    conn.commit()

    print(f"Shop name for ID {product_id1} has been changed to {new_Qty}")

#Edit Product QOH
def edit_prod3():
    product_id2 = input("Enter Item Id ")
    new_stock= input("Enter New price: ")
    cursor.execute("UPDATE stock SET Price = %s WHERE StockId = %s", (new_stock, product_id2))
    conn.commit()

    print(f"Shop name for ID {product_id2} has been changed to {new_stock}")

#ADDS new item to MS SQL DATABASE
def add_item():
    print('Add item:')
    item_name = input('Enter item name: ')
    stock_on_hand = input('Enter stock on hand: ')
    price = input('Enter price: ')
    
    cursor = conn.cursor()
    cursor.execute(f"INSERT INTO stock(StockDescription, QOH, Price) VALUES ('{item_name}','{stock_on_hand}','{price}')")
    conn.commit()
    print(f'Added item: {item_name} ({stock_on_hand} in stock, priced at {price})')

# Displaying data from from MS SQL DATABASE 
def display_stock():
    print(line3)
    print('Stock On Hand:')
    print(line3)
    cursor = conn.cursor()
    cursor.execute("SELECT StockId, StockDescription, QOH, Price FROM stock")
    rows = cursor.fetchall() 
    width = 100
    width1 =15
    print("{:<{}} {:<{}} {:<{}} {:<{}}".format("ID", width1, "Item Name", width, "QOH", width1, "Price", width1))
    print(line3)
    for row in rows:
        print("{:<{}} {:<{}} {:<{}} R {:<{}}".format(row[0], width1, row[1], width, row[2], width1, row[3], width1))
    print(line3)
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
#<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<          
#MAIN MENU
 
def Main_menu(): 
    print('\nMain Menu')
    print('1. Shop Management')
    print('2. Sales')
    print('3. Returns')
    print('4. Customers')
    print('5. Stock')
    print('99. Exit')
    choice = input('Enter choice: ')
    if choice == '1':
        shop_management()
    elif choice == '2':
        sales()
    elif choice == '3':
        sales_return()
    elif choice == '4':
        customer3()    
    elif choice == '5':
        stock()
    else:
        print('Invalid input, please try again.')

while True:
    Main_menu()
#COPYRIGHT BY DILLUN HOLMES AKA:LONEWOLF